Presidential Turnout: historical turnout by race by sex by age group, with state-based deviation

Senate Turnout: regression on "closeness" of race with state controls

Timing: qualitative research into 2020 timing vs closeness of race